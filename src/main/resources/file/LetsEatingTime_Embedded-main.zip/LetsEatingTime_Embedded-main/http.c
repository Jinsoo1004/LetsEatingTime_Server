#include<stdio.h>
#include<curl/curl.h>
#include<string.h>
#include<stdlib.h>

int main(){
	CURL *curl;
	CURLcode res;
	char baseurl[] = "http://192.168.137.1:8080/api/account/login.do";
	
	curl = curl_easy_init();
	
	
	char *postdata1 = "{\"id\":\"1234\",\"password\":\"1234\"}";
	char tostring[100];
	sprintf(tostring, "Content-Length: %d", (int)strlen(postdata1));
	char *tostring_pointer = tostring;
	struct curl_slist *headers1 = NULL;
	struct curl_slist *headers2 = NULL;
	struct curl_slist *headers3 = NULL;
	struct curl_slist *headers4 = NULL;
	
	if(curl){
		headers1 = curl_slist_append(headers1, "Content-Type: application/json");
//		headers2 = curl_slist_append(headers2, tostring_pointer);
//		headers3 = curl_slist_append(headers3, "Accept: */*");
//		headers4 = curl_slist_append(headers4, "Accept-Encoding: gzip, deflate, br");
		curl_easy_setopt(curl, CURLOPT_URL, baseurl);
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 1L);
		curl_easy_setopt(curl, CURLOPT_POST, 1L);
		
		
		
		
		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers1);
//		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers2);
//		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers3);
//		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers4);
		curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postdata1);
		res = curl_easy_perform(curl);
		curl_slist_free_all(headers1);
//
		curl_slist_free_all(headers2);
//		curl_slist_free_all(headers3);
//		curl_slist_free_all(headers4);
		if(res != CURLE_OK){
			fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
		}		

		curl_easy_cleanup(curl);

	}
	return 0;
}
