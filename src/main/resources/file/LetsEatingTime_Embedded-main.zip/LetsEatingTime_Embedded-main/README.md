# LetsEatingTime_Embedded
c언어로 하는 재미있는 http통신과 nfc연결
